=======
# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/)

## [Unreleased]

## [1.0.0] - 2023-05-11
- Initial playbook release 
- Windows facts Playbook
